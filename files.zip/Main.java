import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Lift lift = new Lift(1, Direction.IDLE);
        LiftAllocationService allocationService = new LiftAllocationService();
        Scanner scanner = new Scanner(System.in);
        while(true) {
            while (true) {
                Request request=null;
                System.out.print("Enter pickup floor (-1 to finish, -2 to end the program): ");
                try {

                int pickupFloor = scanner.nextInt();
                if (pickupFloor == -1) {
                    break;
                }
                if (pickupFloor == -2) {
                    return;
                }

                if(pickupFloor>=0&&pickupFloor<=8){
                    request = new Request(pickupFloor);
                }else{
                    throw new IllegalArgumentException();

                }
                }catch (IllegalArgumentException e){
                    System.out.println("Enter valid floor from 0 to 8");
                    continue;
                }catch (InputMismatchException e){
                    scanner.nextLine();   // throw away the wrong input (letters, decimals...)
                    System.out.println("Enter a whole number for the floor");
                    continue;
                }

                scanner.nextLine();
                System.out.print("Enter direction (UP/DOWN, comma-separated if both): ");
                String directions = scanner.nextLine();
                String[] directionVal = directions.split(",");
                for (String value : directionVal) {
                    try {
                        if(value.trim().toUpperCase().equals("IDLE")){
                            throw new IllegalArgumentException();
                        }else {
                            request.addDirection(Direction.valueOf(value.trim().toUpperCase()));
                        }
                    } catch (IllegalArgumentException e) {
                        System.out.println("Invalid direction: " + value + ". Use UP, DOWN, or UP,DOWN.");
                    }
                }
                if (request.getDirection().isEmpty()) {
                    // no valid direction -> do not add an empty request (it would freeze the lift)
                    System.out.println("No valid direction entered, request ignored.");
                    continue;
                }
                allocationService.addRequest(request);
            }
            allocationService.processLift(lift, scanner);
        }
    }
}
