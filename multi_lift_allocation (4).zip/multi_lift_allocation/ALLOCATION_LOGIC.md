# Allocation logic

Names: pickupFloor = floor where the user waits, requestDirection = UP or DOWN (a request has one or both),
liftFloor = lift's current floor, highestNextFloor / lowestNextFloor = last / first floor of the lift's nextFloors TreeSet,
upperTurnFloor = max(highestNextFloor, pickupFloor), lowerTurnFloor = min(lowestNextFloor, pickupFloor).
A lift only goes as far as its last / first next floor (or the pickup floor), never to its highest / lowest floor.

## Input (validated in Main with try/catch)
- Per lift: lowest floor < highest floor, current floor between them, then direction (UP/DOWN/IDLE), asked again if wrong.
- IDLE -> next floors are not asked. UP/DOWN -> next floors (type done to finish).
- Negative floors (basement) are allowed.
- Only ONE pickup request is taken (served floors are never removed from nextFloors, so a second request would use old data).
- Pickup floor must be a floor of at least one lift. A pickup always has a direction: if no valid direction is entered it is asked again.
  A direction is valid if at least one lift can serve it (canServe).

## setDirection (when a lift is added)
The direction the user gave may not match the next floors, so it is corrected:
- no next floors -> IDLE (UP/DOWN with nothing to do is IDLE)
- UP but no next floor above -> DOWN, DOWN but no next floor below -> UP

## canServe(lift, pickupFloor, requestDirection)
The pickup floor is between the lift's lowest and highest floor, and the lift can go in that direction from there
(UP is not possible at its highest floor, DOWN is not possible at its lowest floor). Lifts that cannot are skipped.

## Cost = floors travelled before the door opens at pickupFloor
| Lift | requestDirection | Condition | Cost |
|---|---|---|---|
| IDLE | any | | abs(liftFloor - pickupFloor) |
| UP | UP | pickupFloor >= liftFloor | pickupFloor - liftFloor |
| UP | UP | pickupFloor < liftFloor | (highestNextFloor-liftFloor) + (highestNextFloor-lowerTurnFloor) + (pickupFloor-lowerTurnFloor) |
| UP | DOWN | | (upperTurnFloor-liftFloor) + (upperTurnFloor-pickupFloor) |
| DOWN | DOWN | pickupFloor <= liftFloor | liftFloor - pickupFloor |
| DOWN | DOWN | pickupFloor > liftFloor | (liftFloor-lowestNextFloor) + (upperTurnFloor-lowestNextFloor) + (upperTurnFloor-pickupFloor) |
| DOWN | UP | | (liftFloor-lowerTurnFloor) + (pickupFloor-lowerTurnFloor) |

## Choosing
1. findBestLift (once per direction of the request): go through the lifts that can serve, keep the best lift and its cost so far.
   A lift replaces the best one if its cost is lower; on equal cost the tie breakers decide:
   fewer stops before the pickup floor, IDLE, same direction, opposite direction, lower lift id.
   Stops before the pickup floor = only the next floors on the lift's way to the pickup floor (not behind it, not the pickup floor itself).
   If the lift has to turn around first, the next floors of the whole sweep count.
   Example: lift at 4 going UP, next floors 2,3,5, pickup at 6 -> only floor 5 counts.
2. UP and DOWN got different lifts -> if one of them is equally good for the other direction too, use that one lift. Otherwise two lifts.
3. Print the assigned lift for each direction. The lifts are not changed (single request).
