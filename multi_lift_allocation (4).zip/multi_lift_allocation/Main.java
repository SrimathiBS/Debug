import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        LiftAllocationService allocationService = new LiftAllocationService();

        int noOfLifts = 0;
        while (true) {
            try {
                System.out.print("Enter number of lifts: ");
                noOfLifts = scanner.nextInt();
                if (noOfLifts > 0) {
                    break;
                }
                System.out.println("Number of lifts should be greater than 0");
            } catch (InputMismatchException e) {
                System.out.println("Enter a whole number");
                scanner.nextLine();
            }
        }

        for (int liftNumber = 1; liftNumber <= noOfLifts; liftNumber++) {
            System.out.println("\nLift " + liftNumber);
            int lowestFloor = 0, highestFloor = 0, currentFloor = 0;
            while (true) {
                try {
                    System.out.print("Enter lowest floor: ");
                    lowestFloor = scanner.nextInt();
                    System.out.print("Enter highest floor: ");
                    highestFloor = scanner.nextInt();
                    if (highestFloor <= lowestFloor) {
                        System.out.println("highest floor should not be less than or equal to lowest floor");
                        continue;
                    }
                    while (true) {
                        System.out.print("Enter current floor: ");
                        currentFloor = scanner.nextInt();
                        if (currentFloor < lowestFloor || currentFloor > highestFloor) {
                            System.out.println("Enter current floor from " + lowestFloor + " to " + highestFloor);
                        } else {
                            break;
                        }
                    }
                    break;
                } catch (InputMismatchException e) {
                    System.out.println("Enter valid floor number");
                    scanner.nextLine();
                }
            }

            Lift lift = new Lift(liftNumber, currentFloor, Direction.IDLE, lowestFloor, highestFloor);
            while (true) {
                try {
                    System.out.print("Enter direction of the lift (UP/DOWN/IDLE): ");
                    lift.direction = Direction.valueOf(scanner.next().trim().toUpperCase());
                    break;
                } catch (IllegalArgumentException e) {
                    System.out.println("Invalid direction. Use UP, DOWN or IDLE.");
                }
            }

            // idle lift has no next floors. If no next floor is entered, addLift saves the lift as IDLE
            if (lift.getDirection() != Direction.IDLE) {
                while (true) {
                    System.out.print("Enter next floor (type done to finish): ");
                    try {
                        String input = scanner.next();
                        if (input.equalsIgnoreCase("done")) {
                            break;
                        }
                        int nextFloor = Integer.parseInt(input);
                        if (nextFloor >= lowestFloor && nextFloor <= highestFloor && nextFloor != currentFloor) {
                            lift.nextFloors.add(nextFloor);
                        } else {
                            throw new IllegalArgumentException();
                        }
                    } catch (NumberFormatException e) {
                        scanner.nextLine();
                        System.out.println("Enter a whole number for the floor, or type done");
                    } catch (IllegalArgumentException e) {
                        System.out.println("Enter valid floor from " + lowestFloor + " to " + highestFloor + " and it should not be equal to current floor");
                    }
                }
            }

            allocationService.addLift(lift);
        }

        // only one pickup request is taken, because floors are never removed once the lift serves them
        int pickupFloor = 0;
        while (true) {
            try {
                System.out.print("\nEnter pickup floor: ");
                pickupFloor = scanner.nextInt();
                boolean floorInLiftRange = false;
                for (Lift lift : allocationService.lifts) {
                    if (pickupFloor >= lift.lowestfloor && pickupFloor <= lift.highestfloor) {
                        floorInLiftRange = true;
                    }
                }
                if (floorInLiftRange) {
                    break;
                }
                System.out.println("No lift goes to floor " + pickupFloor);
            } catch (InputMismatchException e) {
                System.out.println("Enter a whole number for the floor");
                scanner.nextLine();   // throw away the wrong input (letters, decimals...)
            }
        }
        scanner.nextLine();           // rest of the line after the floor number

        // a pickup always has a direction, so ask again until at least one valid direction is entered
        Request request = new Request(pickupFloor);
        while (request.getDirection().isEmpty()) {
            System.out.print("Enter direction (UP/DOWN, comma-separated if both): ");
            String[] directionValues = scanner.nextLine().split(",");
            for (String value : directionValues) {
                try {
                    Direction direction = Direction.valueOf(value.trim().toUpperCase());
                    if (direction == Direction.IDLE) {
                        throw new IllegalArgumentException();
                    }
                    boolean directionPossible = false;
                    for (Lift lift : allocationService.lifts) {
                        if (allocationService.canServe(lift, pickupFloor, direction)) {
                            directionPossible = true;
                        }
                    }
                    if (directionPossible) {
                        request.addDirection(direction);
                    } else {
                        System.out.println("Invalid direction: " + direction + " is not possible for floor " + pickupFloor);
                    }
                } catch (IllegalArgumentException e) {
                    System.out.println("Invalid direction: " + value + ". Use UP, DOWN, or UP,DOWN.");
                }
            }
        }

        allocationService.allocateLift(request);
    }
}


//inputs: no. of lifts, each lift's current floor, direction(up,down,idle), lowest floor, highest floor, next floors (treeset), user's pickup floor and direction(s) (up, down or both)
//output: the lift(s) that is assigned to the pickup request. we should assign the lift optimally
