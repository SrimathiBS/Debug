public class Lift {
    int currentFloor;
    Direction direction;

    public Lift(int currentFloor, Direction direction) {
        this.currentFloor = currentFloor;
        this.direction = direction;
    }

    public int getCurrentFloor() {

        return currentFloor;
    }

    public Direction getDirection() {

        return direction;
    }

}
