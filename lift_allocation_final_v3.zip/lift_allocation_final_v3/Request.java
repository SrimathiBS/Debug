import java.util.ArrayList;
import java.util.HashSet;

import java.util.Set;

public class Request implements Comparable<Request> {
    int pickupFloor;
    //HashSet<Integer> destinationFloors;
    ArrayList<Direction> direction;

    public Request(int pickupFloor) {
        this.pickupFloor = pickupFloor;
       // this.destinationFloors = new HashSet<>();
        this.direction = new ArrayList<>();
    }


    public void addDirection(Direction dir) {
        if (!direction.contains(dir)) {
            direction.add(dir);
        }
    }

    public int getPickupFloor() {
        return pickupFloor;
    }


    public ArrayList<Direction> getDirection() {
        return direction;
    }

    @Override
    public int compareTo(Request other) {
        return Integer.compare(pickupFloor, other.pickupFloor);
    }
}
