import java.util.TreeSet;

public class Lift {
    int id;
    int currentFloor;
    Direction direction;
    TreeSet<Integer> nextFloors = new TreeSet<>();

    public Lift(int id, int currentFloor, Direction direction) {
        this.id = id;
        this.currentFloor = currentFloor;
        this.direction = direction;
    }

    public int getCurrentFloor() {

        return currentFloor;
    }

    public Direction getDirection() {

        return direction;
    }

}
