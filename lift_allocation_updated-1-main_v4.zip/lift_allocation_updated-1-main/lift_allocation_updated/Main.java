import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int lowestFloor, highestFloor;
        while (true) {
            lowestFloor = readFloor(scanner, "Enter starting floor (lowest floor): ");
            highestFloor = readFloor(scanner, "Enter ending floor (highest floor): ");
            if (lowestFloor >= 0 && highestFloor > lowestFloor) {
                break;
            }
            System.out.println("Starting floor must be 0 or more, and ending floor must be greater than starting floor");
        }
        Lift lift = new Lift(lowestFloor, Direction.IDLE, lowestFloor, highestFloor);   // lift starts at the starting floor
        LiftAllocationService allocationService = new LiftAllocationService();
        while(true) {
            while (true) {
                Request request=null;
                System.out.print("Enter pickup floor (-1 to finish, -2 to end the program): ");
                try {

                    int pickupFloor = scanner.nextInt();
                    if (pickupFloor == -1) {
                        break;
                    }
                    if (pickupFloor == -2) {
                        return;
                    }

                    if(lift.isValidFloor(pickupFloor)){
                        request = new Request(pickupFloor);
                    }else{
                        throw new IllegalArgumentException();

                    }
                }catch (IllegalArgumentException e){
                    System.out.println("Enter valid floor " + lift.getFloorRange());
                    continue;
                }catch (InputMismatchException e){
                    scanner.nextLine();   // throw away the wrong input (letters, decimals...)
                    System.out.println("Enter a whole number for the floor");
                    continue;
                }

                scanner.nextLine();
                System.out.print("Enter direction (UP/DOWN, comma-separated if both): ");
                String directions = scanner.nextLine();
                String[] directionVal = directions.split(",");
                for (String value : directionVal) {
                    try {
                        if(value.trim().toUpperCase().equals("IDLE")){
                            throw new IllegalArgumentException();
                        }else {
                            Direction direction = Direction.valueOf(value.trim().toUpperCase());
                            if ((request.getPickupFloor() == lift.highestFloor && direction == Direction.UP) ||
                                    (request.getPickupFloor() == lift.lowestFloor && direction == Direction.DOWN)) {
                                System.out.println("Invalid direction: " + direction + " is not possible from floor " + request.getPickupFloor());
                            } else {
                                request.addDirection(direction);
                            }
                        }
                    } catch (IllegalArgumentException e) {
                        System.out.println("Invalid direction: " + value + ". Use UP, DOWN, or UP,DOWN.");
                    }
                }
                if (request.getDirection().isEmpty()) {
                    System.out.println("No valid direction entered, request not added");
                    continue;
                }
                allocationService.addRequest(request);
            }
            allocationService.processLift(lift, scanner);
        }
    }

    // keeps asking until a whole number is entered
    private static int readFloor(Scanner scanner, String message) {
        while (true) {
            System.out.print(message);
            try {
                return scanner.nextInt();
            } catch (InputMismatchException e) {
                scanner.nextLine();
                System.out.println("Enter a whole number for the floor");
            }
        }
    }
}
