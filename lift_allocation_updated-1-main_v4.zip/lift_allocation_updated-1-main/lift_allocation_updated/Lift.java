public class Lift {
    int currentFloor;
    Direction direction;
    int lowestFloor;    // starting floor entered by the user
    int highestFloor;   // ending floor entered by the user

    public Lift(int currentFloor, Direction direction, int lowestFloor, int highestFloor) {
        this.currentFloor = currentFloor;
        this.direction = direction;
        this.lowestFloor = lowestFloor;
        this.highestFloor = highestFloor;
    }

    public int getCurrentFloor() {

        return currentFloor;
    }

    public Direction getDirection() {

        return direction;
    }

    public boolean isValidFloor(int floor) {
        return floor >= lowestFloor && floor <= highestFloor;
    }

    public String getFloorRange() {
        return "from " + lowestFloor + " to " + highestFloor;
    }

}
