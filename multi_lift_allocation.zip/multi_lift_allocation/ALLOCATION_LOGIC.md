# Allocation logic

Symbols: f = pickup floor, d = one direction of the request, c = lift's current floor,
top = LAST floor in the lift's TreeSet, bottom = FIRST floor in the lift's TreeSet,
T = max(top, f) (top turning point), B = min(bottom, f) (bottom turning point).
A lift never goes beyond its last / first pending floor (or f itself), not to the building's highest / lowest floor.

## Input (all validated in Main with try/catch)
- lowest < highest, lowest <= current <= highest
- pending floor: inside the lift's range, not the current floor, direction UP / DOWN / UP,DOWN
  (UP at the highest floor and DOWN at the lowest floor are dropped)
- no pending request -> lift is IDLE and its direction is not asked
- pickup floor: inside the lowest..highest of all lifts, directions validated the same way

## setDirection (on input and after every assignment)
- nothing above and nothing below the current floor -> IDLE
- IDLE with work -> go to the nearest pending floor (tie -> UP)
- UP with nothing above -> DOWN, DOWN with nothing below -> UP

## Cost (floors travelled before the door opens at f for direction d)
Skipped (INF) if f is outside the lift's range, d = UP at the lift's highest floor, d = DOWN at the lift's lowest floor.

| Lift | d | Condition | Cost |
|---|---|---|---|
| IDLE | any | | abs(c - f) |
| UP | UP | f >= c | f - c |
| UP | UP | f < c | (top-c) + (top-B) + (f-B) |
| UP | DOWN | | (T-c) + (T-f) |
| DOWN | DOWN | f <= c | c - f |
| DOWN | DOWN | f > c | (c-bottom) + (T-bottom) + (T-f) |
| DOWN | UP | | (c-B) + (f-B) |

## Choosing
1. Every direction of the request is allocated on its own.
2. Best lift per direction: lower cost, fewer pending requests, IDLE, same direction, opposite direction, lower lift id.
3. UP and DOWN got different lifts -> if one of them is equally good for the other direction too, use that one lift. Otherwise two lifts.
4. Save the request (floor + direction) in the chosen lift's TreeSet (directions merged if the floor exists), then setDirection.
   A lift already standing at f (idle or going the same way) just opens its door, nothing is saved.
