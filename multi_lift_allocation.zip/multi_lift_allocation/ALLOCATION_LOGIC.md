# Multi-Lift Allocation Logic (reference)

## Symbols
| Symbol | Meaning |
|---|---|
| f | pickup floor |
| d | one direction of the request (UP or DOWN) |
| c | lift's current floor |
| hi | max(c, highest pending floor of the lift) |
| lo | min(c, lowest pending floor of the lift) |
| T | top turning point = max(hi, f) |
| B | bottom turning point = min(lo, f) |

## Data
- `Lift`: id, currentFloor, direction (UP/DOWN/IDLE), lowestfloor, highestfloor, `TreeSet<Request> pendingRequests`
- `Request`: pickupFloor + `ArrayList<Direction>` (UP, DOWN or both; empty list = plain destination stop). Compared by floor, so one entry per floor; directions are merged.

## 1. Startup input (per lift)
1. lowest floor >= 0, highest > lowest, current floor inside [lowest, highest], otherwise the lift's details are re-entered (try/catch).
2. Pending floors with directions (UP / DOWN / UP,DOWN / NONE). Rejected if out of range, equal to the current floor, or UP at the highest / DOWN at the lowest floor.
3. No pending request -> lift is IDLE automatically (direction is not asked).
4. Otherwise the direction is entered, then normalised (see 2).

## 2. normalizeDirection (runs on input, before every cost, after every assignment)
1. Nothing pending except the current floor -> remove it (served), direction = IDLE.
2. IDLE with work -> go towards the nearest pending floor (tie -> UP).
3. UP with nothing above -> DOWN. DOWN with nothing below -> UP.
4. Requests waiting at the current floor: an idle lift opens for everyone; a moving lift serves only the direction it is going, the other direction stays pending.

## 3. Eligibility (cost = INF, lift skipped for that direction)
- f outside [lowest, highest] of the lift
- d = UP and f = highest floor of the lift
- d = DOWN and f = lowest floor of the lift

## 4. Cost = floors travelled before the door opens at f for direction d
| Lift | d | Condition | Cost |
|---|---|---|---|
| IDLE (nothing pending) | any | | abs(c - f) |
| UP | UP | f >= c | f - c |
| UP | UP | f < c | B = min(lo,f); (hi-c) + (hi-B) + (f-B) |
| UP | DOWN | | T = max(hi,f); (T-c) + (T-f) |
| DOWN | DOWN | f <= c | c - f |
| DOWN | DOWN | f > c | T = max(hi,f); (c-lo) + (T-lo) + (T-f) |
| DOWN | UP | | B = min(lo,f); (c-B) + (f-B) |

Direction change costs no floors by itself. It is the extra distance to the turning point (T or B) that is counted.

## 5. Choosing the lift
1. For each direction of the request, calculate the cost of every lift (all before anything is changed).
2. For each direction pick the best lift. Tie-breakers in order:
   1. lower cost
   2. fewer pending requests
   3. IDLE lift
   4. lift moving in the same direction as the request
   5. lift moving in the opposite direction
   6. lower lift id
3. Request with UP and DOWN:
   - both directions have the same best lift -> one lift.
   - different best lifts -> use ONE lift only if some lift is exactly as good as both winners (same cost for UP and for DOWN). Otherwise UP and DOWN go to two different lifts.
4. Save: the request (floor + direction) is added to the chosen lift's TreeSet (merging directions if the floor is already there), then that lift is normalised. Without this, the next request is calculated on old data.
5. A direction no lift can serve is reported; if none can be served an exception is thrown and caught.

## 6. Worked example
Lift 1: floor 3, UP, pending {9[DOWN]}. Lift 2: floor 8, DOWN, pending {1[UP]}. Request: floor 6, UP and DOWN.
- Lift 1: UP = 6-3 = 3. DOWN: T = 9, (9-3)+(9-6) = 9.
- Lift 2: UP: B = 1, (8-1)+(6-1) = 12. DOWN = 8-6 = 2.
- Best for UP = Lift 1 (3), best for DOWN = Lift 2 (2). No lift is best at both, so two lifts are assigned.

## 7. Known limitations
- Pending floors are never removed (no movement simulation), so costs only grow during a session.
- Cost counts floors, not time: no door-time per stop, no capacity, no aging for long waits.
- A pickup's destination is unknown at allocation time.
- Pending floors of other pickups are treated as plain stops in the cost table; the stored directions are meant to be used by the movement code.
- Floors cannot be negative (-1 / -2 are console commands).
