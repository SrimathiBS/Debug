import java.util.InputMismatchException;
import java.util.LinkedHashMap;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class Main {
    static int readInt(Scanner scanner, String message) {
        while (true) {
            System.out.print(message);
            try {
                return scanner.nextInt();
            } catch (InputMismatchException e) {
                scanner.nextLine();   // throw away the wrong input
                System.out.println("Enter a whole number");
            }
        }
    }

    static Direction readDirection(Scanner scanner, String message) {
        while (true) {
            System.out.print(message);
            String value = scanner.next().trim().toUpperCase();
            try {
                return Direction.valueOf(value);
            } catch (IllegalArgumentException e) {
                System.out.println("Invalid direction: " + value + ". Use UP, DOWN or IDLE.");
            }
        }
    }

    // UP, DOWN or UP,DOWN. NONE (only when allowNone) = plain destination stop
    static Request readDirections(Scanner scanner, int floor, String message, boolean allowNone) {
        scanner.nextLine();   // finish the line of the floor number
        while (true) {
            System.out.print(message);
            String[] values = scanner.nextLine().split(",");
            Request request = new Request(floor);
            boolean valid = true;
            for (String value : values) {
                String text = value.trim().toUpperCase();
                if (allowNone && text.equals("NONE") && values.length == 1) {
                    return request;
                }
                try {
                    Direction direction = Direction.valueOf(text);
                    if (direction == Direction.IDLE) {
                        throw new IllegalArgumentException();
                    }
                    request.addDirection(direction);
                } catch (IllegalArgumentException e) {
                    System.out.println("Invalid direction: " + value + ". Use UP, DOWN, or UP,DOWN" + (allowNone ? ", or NONE." : "."));
                    valid = false;
                    break;
                }
            }
            if (valid) {
                return request;
            }
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        try {
            run(scanner);
        } catch (NoSuchElementException e) {
            System.out.println("\nInput ended, exiting");
        }
    }

    static void run(Scanner scanner) {
        LiftAllocationService allocationService = new LiftAllocationService();

        int noOfLifts = 0;
        while (noOfLifts <= 0) {
            noOfLifts = readInt(scanner, "Enter number of lifts: ");
            if (noOfLifts <= 0) {
                System.out.println("Number of lifts should be greater than 0");
            }
        }

        for (int i = 1; i <= noOfLifts; i++) {
            System.out.println("\n--- Lift " + i + " ---");
            Lift lift = null;
            while (lift == null) {
                try {
                    int lf = readInt(scanner, "Enter lowest floor: ");
                    int hf = readInt(scanner, "Enter highest floor: ");
                    int cf = readInt(scanner, "Enter current floor: ");
                    if (lf < 0) {
                        throw new IllegalArgumentException("Lowest floor should not be negative");
                    }
                    if (hf <= lf) {
                        throw new IllegalArgumentException("highest floor should not be less than or equal to lowest floor");
                    }
                    if (cf < lf || cf > hf) {
                        throw new IllegalArgumentException("Current floor should be from " + lf + " to " + hf);
                    }
                    lift = new Lift(i, cf, Direction.IDLE, lf, hf);
                } catch (IllegalArgumentException e) {
                    System.out.println(e.getMessage() + ". Enter this lift's details again");
                }
            }

            while (true) {
                int floor = readInt(scanner, "Enter pending floor (-1 to finish): ");
                if (floor == -1) {
                    break;
                }
                Request pending = readDirections(scanner, floor, "Enter direction (UP/DOWN, comma-separated if both, NONE for destination only): ", true);
                try {
                    lift.addPendingRequest(pending, false);
                } catch (IllegalArgumentException e) {
                    System.out.println(e.getMessage());
                }
            }

            if (lift.pendingRequests.isEmpty()) {
                System.out.println("No pending requests, Lift " + i + " is IDLE");
            } else {
                lift.direction = readDirection(scanner, "Enter direction of lift (UP/DOWN/IDLE): ");
            }
            allocationService.addLift(lift);
        }

        System.out.println();
        allocationService.printStatus();

        int lowest = allocationService.getLowestFloor();
        int highest = allocationService.getHighestFloor();

        while (true) {
            System.out.println();
            int pickupFloor = readInt(scanner, "Enter pickup floor (-1 to show status, -2 to end the program): ");
            if (pickupFloor == -2) {
                return;
            }
            if (pickupFloor == -1) {
                allocationService.printStatus();
                continue;
            }
            try {
                if (pickupFloor < lowest || pickupFloor > highest) {
                    throw new IllegalArgumentException("Enter valid floor from " + lowest + " to " + highest);
                }
                Request entered = readDirections(scanner, pickupFloor, "Enter direction (UP/DOWN, comma-separated if both): ", false);

                // directions that are impossible for every lift are dropped
                Request request = new Request(pickupFloor);
                for (Direction direction : entered.getDirection()) {
                    if ((pickupFloor == highest && direction == Direction.UP) || (pickupFloor == lowest && direction == Direction.DOWN)) {
                        System.out.println("Invalid direction: " + direction + " is not possible for floor " + pickupFloor);
                    } else {
                        request.addDirection(direction);
                    }
                }
                if (request.getDirection().isEmpty()) {
                    System.out.println("No valid direction entered, request not added");
                    continue;
                }

                LinkedHashMap<Direction, Lift> assigned = allocationService.allocateLift(request);
                for (Direction direction : request.getDirection()) {
                    Lift lift = assigned.get(direction);
                    if (lift == null) {
                        System.out.println("==> No lift can serve floor " + pickupFloor + " going " + direction);
                    } else {
                        System.out.println("==> Lift " + lift.getId() + " assigned for floor " + pickupFloor + " going " + direction);
                    }
                }
                allocationService.printStatus();
            } catch (IllegalArgumentException | IllegalStateException e) {
                System.out.println(e.getMessage());
            }
        }
    }
}


//inputs: no. of lifts, each lift's current floor, direction(up,down,idle), lowest floor, highest floor, pending requests (treeset of Request), user's pickup floor and direction(s) (up, down or both)
//output: the lift(s) that is assigned to the pickup request. we should assign the lift optimally
