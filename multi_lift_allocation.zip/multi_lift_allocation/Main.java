import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    // reads UP / DOWN / UP,DOWN for the request and keeps only the valid directions
    static void readDirections(Scanner scanner, Request request, int lf, int hf) {
        scanner.nextLine();
        System.out.print("Enter direction (UP/DOWN, comma-separated if both): ");
        String directions = scanner.nextLine();
        String[] directionVal = directions.split(",");
        for (String value : directionVal) {
            try {
                if(value.trim().toUpperCase().equals("IDLE")){
                    throw new IllegalArgumentException();
                }else {
                    Direction direction = Direction.valueOf(value.trim().toUpperCase());
                    if ((request.getPickupFloor() == hf && direction == Direction.UP) ||
                            (request.getPickupFloor() == lf && direction == Direction.DOWN)) {
                        System.out.println("Invalid direction: " + direction + " is not possible for floor " + request.getPickupFloor());
                    } else {
                        request.addDirection(direction);
                    }
                }
            } catch (IllegalArgumentException e) {
                System.out.println("Invalid direction: " + value + ". Use UP, DOWN, or UP,DOWN.");
            }
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        LiftAllocationService allocationService = new LiftAllocationService();

        int noOfLifts = 0;
        while (true) {
            try {
                System.out.print("Enter number of lifts: ");
                noOfLifts = scanner.nextInt();
                if (noOfLifts > 0) {
                    break;
                }
                System.out.println("Number of lifts should be greater than 0");
            } catch (InputMismatchException e) {
                System.out.println("Enter a whole number");
                scanner.nextLine();
            }
        }

        int lowest = Integer.MAX_VALUE, highest = Integer.MIN_VALUE;
        for (int i = 1; i <= noOfLifts; i++) {
            System.out.println("\nLift " + i);
            int lf = 0, hf = 0, cf = 0;
            while (true) {
                try {
                    System.out.print("Enter lowest floor: ");
                    lf = scanner.nextInt();
                    System.out.print("Enter highest floor: ");
                    hf = scanner.nextInt();
                    System.out.print("Enter current floor: ");
                    cf = scanner.nextInt();
                    if (hf <= lf) {
                        System.out.println("highest floor should not be less than or equal to lowest floor");
                    } else if (cf < lf || cf > hf) {
                        System.out.println("Enter current floor from " + lf + " to " + hf);
                    } else {
                        break;
                    }
                } catch (InputMismatchException e) {
                    System.out.println("Enter valid floor number");
                    scanner.nextLine();
                }
            }
            Lift lift = new Lift(i, cf, Direction.IDLE, lf, hf);

            while (true) {
                Request request = null;
                System.out.print("Enter pending floor (-1 to finish): ");
                try {
                    int pendingFloor = scanner.nextInt();
                    if (pendingFloor == -1) {
                        break;
                    }
                    if (pendingFloor >= lf && pendingFloor <= hf && pendingFloor != cf) {
                        request = new Request(pendingFloor);
                    } else {
                        throw new IllegalArgumentException();
                    }
                } catch (IllegalArgumentException e) {
                    System.out.println("Enter valid floor from " + lf + " to " + hf + " and it should not be equal to current floor");
                    continue;
                } catch (InputMismatchException e) {
                    scanner.nextLine();
                    System.out.println("Enter a whole number for the floor");
                    continue;
                }

                readDirections(scanner, request, lf, hf);
                if (request.getDirection().isEmpty()) {
                    System.out.println("No valid direction entered, request not added");
                    continue;
                }
                allocationService.addRequest(lift, request);
            }

            // no pending request -> lift stays IDLE
            if (!lift.pendingRequests.isEmpty()) {
                while (true) {
                    try {
                        System.out.print("Enter direction of the lift (UP/DOWN/IDLE): ");
                        lift.direction = Direction.valueOf(scanner.next().trim().toUpperCase());
                        break;
                    } catch (IllegalArgumentException e) {
                        System.out.println("Invalid direction. Use UP, DOWN or IDLE.");
                    }
                }
            }
            allocationService.addLift(lift);
            lowest = Math.min(lowest, lf);
            highest = Math.max(highest, hf);
        }

        while (true) {
            Request request = null;
            System.out.print("\nEnter pickup floor (-2 to end the program): ");
            try {
                int pickupFloor = scanner.nextInt();
                if (pickupFloor == -2) {
                    return;
                }
                if (pickupFloor >= lowest && pickupFloor <= highest) {
                    request = new Request(pickupFloor);
                } else {
                    throw new IllegalArgumentException();
                }
            } catch (IllegalArgumentException e) {
                System.out.println("Enter valid floor from " + lowest + " to " + highest);
                continue;
            } catch (InputMismatchException e) {
                scanner.nextLine();   // throw away the wrong input (letters, decimals...)
                System.out.println("Enter a whole number for the floor");
                continue;
            }

            readDirections(scanner, request, lowest, highest);
            if (request.getDirection().isEmpty()) {
                System.out.println("No valid direction entered, request not added");
                continue;
            }
            allocationService.allocateLift(request);
        }
    }
}


//inputs: no. of lifts, each lift's current floor, direction(up,down,idle), lowest floor, highest floor, pending requests (treeset of Request), user's pickup floor and direction(s) (up, down or both)
//output: the lift(s) that is assigned to the pickup request. we should assign the lift optimally
