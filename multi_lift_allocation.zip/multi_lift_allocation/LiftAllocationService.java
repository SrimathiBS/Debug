import java.util.ArrayList;
import java.util.LinkedHashMap;

public class LiftAllocationService {
    static final int INF = Integer.MAX_VALUE;
    ArrayList<Lift> lifts = new ArrayList<>();

    public void addLift(Lift lift) {
        Direction given = lift.direction;
        normalizeDirection(lift);
        if (given != lift.direction) {
            System.out.println("Lift " + lift.id + " direction adjusted from " + given + " to " + lift.direction
                    + " (based on its pending floors)");
        }
        lifts.add(lift);
    }

    public int getLowestFloor() {
        int low = Integer.MAX_VALUE;
        for (Lift lift : lifts) {
            low = Math.min(low, lift.lowestfloor);
        }
        return low;
    }

    public int getHighestFloor() {
        int high = Integer.MIN_VALUE;
        for (Lift lift : lifts) {
            high = Math.max(high, lift.highestfloor);
        }
        return high;
    }

    // Keeps direction and pending requests consistent:
    // 1. nothing to serve (apart from the current floor) -> IDLE
    // 2. IDLE lift with work -> go towards the nearest pending floor (tie -> UP)
    // 3. UP lift with nothing above (or DOWN with nothing below) -> turn around
    // 4. whatever is waiting at the current floor for the lift's direction is served now
    public void normalizeDirection(Lift lift) {
        Request probe = new Request(lift.currentFloor);
        Request here = lift.pendingRequests.ceiling(probe);
        if (here != null && here.compareTo(probe) != 0) {
            here = null;
        }
        Request higherReq = lift.pendingRequests.higher(probe);
        Request lowerReq = lift.pendingRequests.lower(probe);

        if (higherReq == null && lowerReq == null) {
            if (here != null) {
                lift.pendingRequests.remove(here);
            }
            lift.direction = Direction.IDLE;
            return;
        }

        boolean wasIdle = (lift.direction == Direction.IDLE);
        if (wasIdle) {
            if (higherReq == null) {
                lift.direction = Direction.DOWN;
            } else if (lowerReq == null) {
                lift.direction = Direction.UP;
            } else {
                lift.direction = (higherReq.getPickupFloor() - lift.currentFloor <= lift.currentFloor - lowerReq.getPickupFloor())
                        ? Direction.UP : Direction.DOWN;
            }
        }
        if (lift.direction == Direction.UP && higherReq == null) {
            lift.direction = Direction.DOWN;
        } else if (lift.direction == Direction.DOWN && lowerReq == null) {
            lift.direction = Direction.UP;
        }

        if (here != null) {
            if (wasIdle) {
                lift.pendingRequests.remove(here);          // idle lift opens its door for everyone here
            } else {
                here.getDirection().remove(lift.direction); // only the direction it is going is served
                if (here.getDirection().isEmpty()) {
                    lift.pendingRequests.remove(here);
                }
            }
        }
    }

    // Number of floors the lift has to travel before it opens its door at floor f for direction d
    public int calculateCost(Lift lift, int f, Direction d) {
        // eligibility
        if (f < lift.lowestfloor || f > lift.highestfloor) return INF;
        if (d == Direction.UP && f == lift.highestfloor) return INF;
        if (d == Direction.DOWN && f == lift.lowestfloor) return INF;

        normalizeDirection(lift);
        int c = lift.currentFloor;

        if (lift.pendingRequests.isEmpty()) {
            return Math.abs(c - f);
        }

        int hi = Math.max(c, lift.pendingRequests.last().getPickupFloor());
        int lo = Math.min(c, lift.pendingRequests.first().getPickupFloor());

        if (lift.direction == Direction.UP) {
            if (d == Direction.UP) {
                if (f >= c) {
                    return f - c;
                }
                int B = Math.min(lo, f);
                return (hi - c) + (hi - B) + (f - B);
            }
            int T = Math.max(hi, f);
            return (T - c) + (T - f);
        } else {
            if (d == Direction.DOWN) {
                if (f <= c) {
                    return c - f;
                }
                int T = Math.max(hi, f);
                return (c - lo) + (T - lo) + (T - f);
            }
            int B = Math.min(lo, f);
            return (c - B) + (f - B);
        }
    }

    // 0 = idle, 1 = same direction as request, 2 = opposite
    private int rank(Lift lift, Direction requestDirection) {
        if (lift.direction == Direction.IDLE) return 0;
        if (lift.direction == requestDirection) return 1;
        return 2;
    }

    // tie breaker order: cost, no of pending requests, idle, same direction, opposite, lift id
    private boolean isBetter(Lift lift, int cost, Lift best, int bestCost, Direction requestDirection) {
        if (best == null) return true;
        if (cost != bestCost) return cost < bestCost;
        if (lift.pendingRequests.size() != best.pendingRequests.size()) {
            return lift.pendingRequests.size() < best.pendingRequests.size();
        }
        int r1 = rank(lift, requestDirection);
        int r2 = rank(best, requestDirection);
        if (r1 != r2) return r1 < r2;
        return lift.id < best.id;
    }

    // Every direction of the request is allocated on its own, so UP and DOWN can go to
    // two different lifts when that is better. If one lift is equally good for both, use that one lift.
    // Directions that no lift can serve are missing in the returned map.
    public LinkedHashMap<Direction, Lift> allocateLift(Request request) {
        if (lifts.isEmpty()) {
            throw new IllegalStateException("No lifts available");
        }
        ArrayList<Direction> dirs = request.getDirection();
        if (dirs.isEmpty()) {
            throw new IllegalArgumentException("Pickup request should have at least one direction");
        }

        int f = request.getPickupFloor();
        int n = lifts.size();

        // 1. cost of every lift for every direction (all calculated before anything is changed)
        int[][] cost = new int[dirs.size()][n];
        for (int j = 0; j < n; j++) {
            StringBuilder line = new StringBuilder("Lift " + lifts.get(j).id + " ->");
            for (int i = 0; i < dirs.size(); i++) {
                cost[i][j] = calculateCost(lifts.get(j), f, dirs.get(i));
                line.append(" ").append(dirs.get(i)).append(": ")
                        .append(cost[i][j] == INF ? "cannot serve" : "cost " + cost[i][j]).append(" |");
            }
            System.out.println(line);
        }

        // 2. best lift for each direction
        int[] bestIdx = new int[dirs.size()];
        for (int i = 0; i < dirs.size(); i++) {
            bestIdx[i] = -1;
            for (int j = 0; j < n; j++) {
                if (cost[i][j] == INF) continue;
                if (bestIdx[i] == -1 || isBetter(lifts.get(j), cost[i][j], lifts.get(bestIdx[i]), cost[i][bestIdx[i]], dirs.get(i))) {
                    bestIdx[i] = j;
                }
            }
        }

        // 3. different lifts for UP and DOWN -> use one lift only if it is as good as both of them
        if (dirs.size() == 2 && bestIdx[0] != -1 && bestIdx[1] != -1 && bestIdx[0] != bestIdx[1]) {
            int single = -1;
            for (int j = 0; j < n; j++) {
                if (cost[0][j] == cost[0][bestIdx[0]] && cost[1][j] == cost[1][bestIdx[1]]) {
                    if (single == -1 || isBetter(lifts.get(j), cost[0][j] + cost[1][j], lifts.get(single),
                            cost[0][single] + cost[1][single], dirs.get(0))) {
                        single = j;
                    }
                }
            }
            if (single != -1) {
                bestIdx[0] = single;
                bestIdx[1] = single;
            }
        }

        // 4. save the request in the chosen lift(s), otherwise next allocation uses old data
        LinkedHashMap<Direction, Lift> assigned = new LinkedHashMap<>();
        for (int i = 0; i < dirs.size(); i++) {
            if (bestIdx[i] == -1) continue;
            Lift lift = lifts.get(bestIdx[i]);
            Request single = new Request(f);
            single.addDirection(dirs.get(i));
            lift.addPendingRequest(single, true);   // merges directions if the floor is already pending
            normalizeDirection(lift);
            assigned.put(dirs.get(i), lift);
        }

        if (assigned.isEmpty()) {
            throw new IllegalStateException("No lift can serve floor " + f + " going " + dirs);
        }
        return assigned;
    }

    public void printStatus() {
        for (Lift lift : lifts) {
            System.out.println("Lift " + lift.id + " | floor " + lift.currentFloor + " | " + lift.direction
                    + " | range " + lift.lowestfloor + "-" + lift.highestfloor + " | pending " + lift.pendingRequests);
        }
    }
}
