import java.util.ArrayList;

public class LiftAllocationService {
    static final int INF = Integer.MAX_VALUE;
    ArrayList<Lift> lifts = new ArrayList<>();

    public void addLift(Lift lift) {
        setDirection(lift);
        lifts.add(lift);
    }

    public void addRequest(Lift lift, Request request) {
        Request existing = lift.pendingRequests.ceiling(request);

        if (existing != null && existing.compareTo(request) == 0) {
            // Merge dir
            for (Direction dir : request.getDirection()) {
                existing.addDirection(dir);
            }
        } else {
            // No existing request for this pickup floor
            lift.pendingRequests.add(request);
        }
    }

    // keep the direction correct for the pending requests
    public void setDirection(Lift lift) {
        Request current = new Request(lift.currentFloor);
        Request above = lift.pendingRequests.higher(current);
        Request below = lift.pendingRequests.lower(current);

        if (above == null && below == null) {
            lift.direction = Direction.IDLE;
        } else if (lift.direction == Direction.IDLE) {
            // go to the nearest pending floor
            if (below == null || (above != null && above.getPickupFloor() - lift.currentFloor <= lift.currentFloor - below.getPickupFloor())) {
                lift.direction = Direction.UP;
            } else {
                lift.direction = Direction.DOWN;
            }
        } else if (lift.direction == Direction.UP && above == null) {
            lift.direction = Direction.DOWN;
        } else if (lift.direction == Direction.DOWN && below == null) {
            lift.direction = Direction.UP;
        }
    }

    // floors the lift travels before it opens its door at floor f for direction d
    // turning point of the lift = last (or first) floor in its treeset, it never goes further than that
    public int calculateCost(Lift lift, int f, Direction d) {
        if (f < lift.lowestfloor || f > lift.highestfloor) return INF;
        if ((d == Direction.UP && f == lift.highestfloor) || (d == Direction.DOWN && f == lift.lowestfloor)) return INF;

        int c = lift.currentFloor;
        if (lift.direction == Direction.IDLE) {
            return Math.abs(c - f);
        }

        int top = lift.pendingRequests.last().getPickupFloor();
        int bottom = lift.pendingRequests.first().getPickupFloor();

        if (lift.direction == Direction.UP) {
            if (d == Direction.UP) {
                if (f >= c) return f - c;
                int B = Math.min(bottom, f);
                return (top - c) + (top - B) + (f - B);
            }
            int T = Math.max(top, f);
            return (T - c) + (T - f);
        } else {
            if (d == Direction.DOWN) {
                if (f <= c) return c - f;
                int T = Math.max(top, f);
                return (c - bottom) + (T - bottom) + (T - f);
            }
            int B = Math.min(bottom, f);
            return (c - B) + (f - B);
        }
    }

    // tie breaker: cost, no of pending requests, idle, same direction, opposite, lift id
    private boolean isBetter(Lift lift, int cost, Lift best, int bestCost, Direction d) {
        if (cost != bestCost) return cost < bestCost;
        if (lift.pendingRequests.size() != best.pendingRequests.size()) {
            return lift.pendingRequests.size() < best.pendingRequests.size();
        }
        if (rank(lift, d) != rank(best, d)) return rank(lift, d) < rank(best, d);
        return lift.id < best.id;
    }

    private int rank(Lift lift, Direction d) {
        if (lift.direction == Direction.IDLE) return 0;
        return lift.direction == d ? 1 : 2;
    }

    // every direction of the request gets its own best lift, so UP and DOWN can go to 2 different lifts
    public void allocateLift(Request request) {
        int f = request.getPickupFloor();
        ArrayList<Direction> dirs = request.getDirection();
        Lift[] best = new Lift[dirs.size()];
        int[] bestCost = new int[dirs.size()];

        for (int i = 0; i < dirs.size(); i++) {
            for (Lift lift : lifts) {
                int cost = calculateCost(lift, f, dirs.get(i));
                if (cost != INF && (best[i] == null || isBetter(lift, cost, best[i], bestCost[i], dirs.get(i)))) {
                    best[i] = lift;
                    bestCost[i] = cost;
                }
            }
        }

        // 2 different lifts, but one of them is equally good for both directions -> use that one lift
        if (dirs.size() == 2 && best[0] != null && best[1] != null && best[0] != best[1]) {
            if (calculateCost(best[0], f, dirs.get(1)) == bestCost[1]) {
                best[1] = best[0];
            } else if (calculateCost(best[1], f, dirs.get(0)) == bestCost[0]) {
                best[0] = best[1];
            }
        }

        for (int i = 0; i < dirs.size(); i++) {
            Lift lift = best[i];
            if (lift == null) {
                System.out.println("No lift can serve floor " + f + " going " + dirs.get(i));
                continue;
            }
            // lift already standing at the floor (idle or going the same way) opens its door, nothing to save
            if (!(f == lift.currentFloor && (lift.direction == Direction.IDLE || lift.direction == dirs.get(i)))) {
                Request single = new Request(f);
                single.addDirection(dirs.get(i));
                addRequest(lift, single);
                setDirection(lift);
            }
            System.out.println("Lift " + lift.id + " assigned for floor " + f + " going " + dirs.get(i));
        }
    }
}
