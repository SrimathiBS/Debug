import java.util.TreeSet;

public class Lift {
    int id;
    int currentFloor;
    Direction direction;
    int lowestfloor;
    int highestfloor;
    TreeSet<Request> pendingRequests = new TreeSet<>();

    public Lift(int id, int currentFloor, Direction direction, int lowestfloor, int highestfloor) {
        this.id = id;
        this.currentFloor = currentFloor;
        this.direction = direction;
        this.lowestfloor = lowestfloor;
        this.highestfloor = highestfloor;
    }

    // validate first, save only if valid
    // request with empty direction list = plain destination stop
    // allowCurrentFloor is false for the pending floors typed at the start,
    // true for a pickup that is assigned later (the person can be standing at the lift's floor)
    public void addPendingRequest(Request request, boolean allowCurrentFloor) {
        int floor = request.getPickupFloor();
        if (floor < lowestfloor || floor > highestfloor) {
            throw new IllegalArgumentException("Enter valid floor from " + lowestfloor + " to " + highestfloor);
        }
        if (!allowCurrentFloor && floor == currentFloor) {
            throw new IllegalArgumentException("Pending floor should not be equal to the lift's current floor");
        }
        for (Direction dir : request.getDirection()) {
            if ((floor == highestfloor && dir == Direction.UP) || (floor == lowestfloor && dir == Direction.DOWN)) {
                throw new IllegalArgumentException("Invalid direction: " + dir + " is not possible for floor " + floor);
            }
        }

        Request existing = pendingRequests.ceiling(request);
        if (existing != null && existing.compareTo(request) == 0) {
            // Merge dir
            for (Direction dir : request.getDirection()) {
                existing.addDirection(dir);
            }
        } else {
            pendingRequests.add(request);
        }
    }

    public int getId() {

        return id;
    }

    public int getCurrentFloor() {

        return currentFloor;
    }

    public Direction getDirection() {

        return direction;
    }
}
