# Allocation logic

Names: pickupFloor = floor where the user waits, requestDirection = UP or DOWN (a request can have both),
liftFloor = lift's current floor, highestNextFloor / lowestNextFloor = last / first floor of the lift's nextFloors TreeSet,
upperTurnFloor = max(highestNextFloor, pickupFloor), lowerTurnFloor = min(lowestNextFloor, pickupFloor).
A lift only goes as far as its last / first next floor (or the pickup floor), never to the building's highest / lowest floor.

## Input
- Per lift: lowest floor < highest floor, current floor inside them, then the direction (UP/DOWN/IDLE).
- IDLE -> next floors are not asked. UP/DOWN -> next floors are asked (type done to finish).
- UP/DOWN but no next floor entered -> saved as IDLE (addLift -> setDirection).
- Negative floors (basement) are allowed. Input ends with the words done / exit, not with numbers.
- Pickup floor must be inside the lowest..highest of all lifts. Directions: UP, DOWN or UP,DOWN.

## setDirection (on input and after every assignment)
- no next floor above or below -> IDLE
- IDLE with next floors -> go to the nearest one (tie -> UP)
- UP with nothing above -> DOWN, DOWN with nothing below -> UP

## Cost = floors travelled before the door opens at pickupFloor
CANNOT_SERVE (= Integer.MAX_VALUE, "infinite cost") when the pickup floor is outside the lift's floors,
or requestDirection is UP at the lift's highest floor, or DOWN at its lowest floor. Such a lift is skipped.

| Lift | requestDirection | Condition | Cost |
|---|---|---|---|
| IDLE | any | | abs(liftFloor - pickupFloor) |
| UP | UP | pickupFloor >= liftFloor | pickupFloor - liftFloor |
| UP | UP | pickupFloor < liftFloor | (highestNextFloor-liftFloor) + (highestNextFloor-lowerTurnFloor) + (pickupFloor-lowerTurnFloor) |
| UP | DOWN | | (upperTurnFloor-liftFloor) + (upperTurnFloor-pickupFloor) |
| DOWN | DOWN | pickupFloor <= liftFloor | liftFloor - pickupFloor |
| DOWN | DOWN | pickupFloor > liftFloor | (liftFloor-lowestNextFloor) + (upperTurnFloor-lowestNextFloor) + (upperTurnFloor-pickupFloor) |
| DOWN | UP | | (liftFloor-lowerTurnFloor) + (pickupFloor-lowerTurnFloor) |

## Choosing
1. Every direction of the request is allocated on its own.
2. Best lift per direction: lower cost, fewer next floors, IDLE, same direction, opposite direction, lower lift id.
3. UP and DOWN got different lifts -> if one of them is equally good for the other direction too, use that one lift. Otherwise two lifts.
4. Add the pickup floor to the chosen lift's nextFloors, then setDirection.
   A lift already standing at the pickup floor (idle or going the same way) just opens its door, nothing is added.
